# Forest Leaves — Vencord theme

This package uses the exact background image supplied by the user, saved as `background.png`. The CSS does not add a gradient or tint over the wallpaper.

## GitHub setup
1. Create a **Public** GitHub repository named `forest-leaves-vencord`.
2. Upload `forest-leaves.theme.css` and `background.png` to the repository root and commit them to `main`.
3. Edit `forest-leaves.theme.css` and replace `YOUR_USERNAME` in the image URL with your GitHub username.
4. Commit the CSS change.

## Install in Vencord
In Discord, open **User Settings → Vencord → Themes**. Under **Online Themes**, add:

`https://raw.githubusercontent.com/YOUR_USERNAME/forest-leaves-vencord/main/forest-leaves.theme.css`

Replace `YOUR_USERNAME` with your GitHub username.

The repository must be public so the wallpaper can load. Discord/Vencord class names can change over time, so some panel styling may need updates after Discord updates.
